var crypto = require('crypto-js')

var secretData ={
    name: 'Amar',
    pass:'pass@123'
}
var secretKey='098abc'

var em=crypto.AES.encrypt(JSON.stringify(secretData),secretKey)

console.log('encrypted data' , em.toString())

var cd=crypto.AES.decrypt(em,secretKey)


var data= JSON.parse(cd.toString(crypto.enc.Utf8));

console.log(data)
