var argv= require('yargs')
.command('adduser' ,'add the user' ,function(yargs){
yargs.options({
    fname: {
        demand: true,
        alias:'f',
        description:'Enter your first name',
        type: 'string'
    },
    lname: {
        demand: true,
        alias:'l',
        description:'Enter your last name',
        type: 'string'
    }
}).help('help');
}).help('help').argv

var command= argv._[0]

console.log(command)
if(command == 'adduser' && typeof argv.fname !== 'undefined' && typeof argv.lname !== 'undefined' ){
    console.log('Hello ' +  argv.fname + ' ' +  argv.lname)
} else if
    (command == 'welcome'){
    console.log('its matched with ' +  'welcome')
}