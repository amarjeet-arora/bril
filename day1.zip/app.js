


console.log('password manager app')

var storage= require('node-persist');
storage.initSync();


storage.setItemSync('accounts', [{
    username: 'Asreet',
    initBalance:300
},
{
    username: 'Amar',
    initBalance:300
}
])

var accounts=storage.getItemSync('accounts');


console.log(accounts)
