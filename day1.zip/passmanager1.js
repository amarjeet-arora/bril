var storage= require('node-persist');
storage.initSync();

var argv= require('yargs')
.command('createuser' ,'add the user' ,function(yargs){
yargs.options({
    accname: {
        demand: true,
        alias:'a',
        description:'Enter your account name',
        type: 'string'
    },
    username: {
        demand: true,
        alias:'u',
        description:'Enter your username',
        type: 'string'
    },
    password: {
        demand: true,
        alias:'p',
        description:'Enter your password',
        type: 'string'
    }
}).help('help');
})

.command('getuser' ,'find the user' ,function(yargs){
    yargs.options({
        accname: {
            demand: true,
            alias:'a',
            description:'Enter your account name',
            type: 'string'
        }
    }).help('help');

}).help('help').argv

var command= argv._[0]

console.log(command)

function createAccount(account) {
    var accounts= storage.getItemSync('accounts')

    if(typeof accounts == 'undefined'){
        accounts=[]
    }
    accounts.push(account)
    storage.setItemSync('accounts',accounts)

    return account;
}

function getAccount(accName) {
    var accounts=storage.getItemSync('accounts')
    var matchedAccount

    accounts.forEach(function(account) {
        if(account.accName === accName) {
            matchedAccount=account
        }
    });

    return matchedAccount
}
if(command =='createuser') {
    var createdAccount= createAccount({
        accname: argv.accname,
        username:argv.username,
        password:argv.password
    })
    console.log(createdAccount)
}else if (command =='getuser') {
    var fetchedAccount =getAccount(argv.accName)

    if( typeof fetchedAccount =='undefined'){
        console.log('Account not found')
    } else {
        console.log('Account Found')
        console.log(fetchedAccount)
    }
}
