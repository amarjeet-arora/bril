var storage = require('node-persist');
storage.initSync();
var crypto = require('crypto-js')
var argv = require('yargs')
    .command('createuser', 'add the user', function (yargs) {
        yargs.options({
            accname: {
                demand: true,
                alias: 'a',
                description: 'Enter your account name',
                type: 'string'
            },
            username: {
                demand: true,
                alias: 'u',
                description: 'Enter your username',
                type: 'string'
            },
            password: {
                demand: true,
                alias: 'p',
                description: 'Enter your password',
                type: 'string'
            },
            masterpassword: {
                demand: true,
                alias: 'm',
                description: 'Enter your master password',
                type: 'string'
            }
        }).help('help');
    })

    .command('getuser', 'find the user', function (yargs) {
        yargs.options({
            accname: {
                demand: true,
                alias: 'a',
                description: 'Enter your account name',
                type: 'string'
            },
            masterpassword: {
                demand: true,
                alias: 'm',
                description: 'Enter your master password',
                type: 'string'
            }
        }).help('help');

    }).help('help').argv

var command = argv._[0]




function getAccounts(masterPassword) {
    var ea = storage.getItemSync('accounts')
    var accounts = []
    if (typeof ea !== 'undefined') {
        var bytes = crypto.AES.decrypt(ea, masterPassword)
        accounts = JSON.parse(bytes.toString(crypto.enc.Utf8));
    }
    return accounts;
}

function saveAccounts(accounts, masterPassword) {
    var ea = crypto.AES.encrypt(JSON.stringify(accounts), masterPassword)

    storage.setItemSync('accounts', ea.toString())
}


function createAccount(account, masterPassword) {
    var accounts = getAccounts(masterPassword)

    accounts.push(account)
    saveAccounts(accounts, masterPassword)

    return account;
}

function getAccount(accName, masterPassword) {

    var accounts = getAccounts(masterPassword)
    var matchedAccount
    accounts.forEach(function (account) {
        if (account.accName === accName) {
            matchedAccount = account
        }
    });

    return matchedAccount
}
if (command == 'createuser') {
    var createdAccount = createAccount({
        accname: argv.accname,
        username: argv.username,
        password: argv.password
    },
        argv.masterpassword)
    console.log(createdAccount)
} else if (command == 'getuser') {
    var fetchedAccount = getAccount(argv.accName, argv.masterpassword)

    if (typeof fetchedAccount == 'undefined') {
        console.log('Account not found')
    } else {
        console.log('Account Found')
        console.log(fetchedAccount)
    }
}
