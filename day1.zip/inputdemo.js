var argv1= require('yargs').argv

var command =argv1._[0]



if(command == 'welcome' && typeof argv1.name !== 'undefined' && typeof argv1.email !== 'undefined' && typeof argv1.city !== 'undefined'){
    console.log('Hello ' +  argv1.name + ' my email is ' +  argv1.email + ' and my city is ' +  argv1.city)
} else if
    (command == 'welcome'){
    console.log('its matched with ' +  'welcome')
}

