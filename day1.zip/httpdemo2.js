
var http= require('http')
url= require('url')

http.createServer(function(req,res) {
    var pathname=url.parse(req.url).pathname

    if(pathname === '/') {
        res.writeHead(200, {
            'Content-Type': 'text/plain'
        })
        res.end('Home Page\n')
    } else if(pathname === '/about') {
        res.writeHead(200, {
            'Content-Type': 'text/plain'
        })
        res.end('About Us\n')
    }
    else if(pathname === '/login') {
        res.writeHead(200, {
            'Content-Type': 'text/plain'
        })
        res.end('Login page\n')
    }
    else  {
        res.writeHead(404, {
            'Content-Type': 'text/plain'
        })
        res.end('Page not Found\n')
    }



   
  
}).listen(5000,"127.0.0.1")
console.log('server is started')