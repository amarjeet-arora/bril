var express= require('express')
var bp= require('body-parser')
var app= express();
const db= require('./dbconn')
app.use(bp.json())

const dbname='myapp'
const collname='students'

db.initDB(dbname,collname,function(dbcol){
    console.log('welcome')
    dbcol.find().toArray(function(err,result){
        console.log(result)
    })


app.post("/adduser",(req,res) =>{
    const data= req.body;
    dbcol.insertOne(data,(error,result) =>{
        dbcol.find().toArray(function(err,_result){
            res.json(_result)

    })
})



app.get("/loaduser/:id",(req,res) =>{
    const uid= parseInt(req.params.id);
    dbcol.findOne({id:uid},(err,result) =>{
console.log(result)
    })
})


app.put("/loaduser/:id",(req,res) =>{
    const uid= req.params.id;
    dbcol.findOne({id:uid},(err,result) =>{
const data= req.body;

dbcol.updateOne({id:uid},{$set :data} ,(err,result) =>{
    dbcol.find().toArray(function(err,_result){
        res.json(_result)
})

    })
})

app.delete("/deleteuser/:id",(req,res) =>{
    const uid= req.params.id;
    console.log(uid)
    dbcol.findOne({id:uid},(err,result) =>{
dbcol.deleteOne({id:uid},(err,result) =>{
    dbcol.find().toArray(function(err,_result){
        res.json(_result)
})

    })
})

})
})
})
})



app.listen(3000,() =>{
    console.log('server is ready')
})